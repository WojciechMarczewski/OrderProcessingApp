﻿namespace OrderProcessingApp.Models.Enums
{
    public enum PaymentMethod
    {
        Card,
        CashOnDelivery
    }
}
