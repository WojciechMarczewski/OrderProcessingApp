﻿namespace OrderProcessingApp.Models.Enums
{
    public enum ClientType
    {
        Company,
        Person
    }
}
